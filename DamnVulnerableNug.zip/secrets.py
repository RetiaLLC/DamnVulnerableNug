secrets = {
    'ssid' : 'yourWIFI',
    'password' : 'yourPASSWORD',
    'aio_username' : '_your_adafruit_io_username_',
    'aio_key' : '_your_big_huge_super_long_aio_key_',
    'broker' : 'io.adafruit.com',
    'port' : 1883
    }# Write your code here :-)
