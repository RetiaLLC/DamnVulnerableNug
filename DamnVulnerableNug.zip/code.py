import time
import ipaddress
import wifi
import socketpool
import ssl
import adafruit_requests
import adafruit_requests as requests
import ampule
from board import *
import busio
import displayio
import adafruit_framebuf
import adafruit_displayio_sh1106
import random

TEXT_URL = "https://raw.githubusercontent.com/danielmiessler/SecLists/master/Usernames/top-usernames-shortlist.txt"

## Screen setup and function to change image on the screen

displayio.release_displays()
WIDTH = 130 # Change these to the right size for your display!
HEIGHT = 64
BORDER = 1
i2c = busio.I2C(SCL, SDA) # Create the I2C interface.
display_bus = displayio.I2CDisplay(i2c, device_address=0x3c)
display = adafruit_displayio_sh1106.SH1106(display_bus, width=WIDTH, height=HEIGHT) # Create the SH1106 OLED class.

def NugEyes(IMAGE): ## Make a function to put eyes on the screen
    bitmap = displayio.OnDiskBitmap(IMAGE) # Setup the file as the bitmap data source
    tile_grid = displayio.TileGrid(bitmap, pixel_shader=bitmap.pixel_shader) # Create a TileGrid to hold the bitmap
    group = displayio.Group() # Create a Group to hold the TileGrid
    group.append(tile_grid) # Add the TileGrid to the Group
    display.show(group) # Add the Group to the Display

NugEyes("/faces/mybird.bmp")

def getHTML(filepath):
    f = open(filepath,'r', encoding="utf-8")
    html = f.read()
    f.close()
    return html

## Here are the headers we send when someone wins

victoryHeaders = {
    "Location": "http://doogle.com/",
    "Connection": 'close',
    "Content-Length": '0',
}

@ampule.route("/")
def light_set(request):
    return (200, {}, getHTML('login.html'))


@ampule.route("/login", method='POST')
def login(request):
    print(str(request.body))
    ini_string1 = str(request.body)
    print ("Initial String", ini_string1)
    loginPair = dict(item.split("=") for item in ini_string1.split("&"))
    # Printing resultant string
    #print ("Resultant dictionary", str(loginPair))
    if loginPair["username"].lower() != gameUser:
        NugEyes("/faces/emocat.bmp")
        time.sleep(.1)
        NugEyes("/faces/mybird.bmp")
        website = getHTML('fail.html').format("Invalid Username.")
        return (200, {}, website)
    if loginPair["password"] != gamePass:
        NugEyes("/faces/emocat.bmp")
        time.sleep(.1)
        NugEyes("/faces/mybird.bmp")
        website = getHTML('fail.html').format("Wrong Password!")
        return (200, {}, website)
    else:
        print("wow")
        NugEyes("/faces/boingo.bmp")
        return (302, victoryHeaders, "Hi there, %s!, a winner is u!" % loginPair["username"])

# FROM THIS LINE TO 108 IS ALL SETTING UP WI-FI

for network in wifi.radio.start_scanning_networks():
    print(network, network.ssid, network.channel)
wifi.radio.stop_scanning_networks()

try:
    from secrets import secrets
except ImportError:
    print("WiFi secrets are kept in secrets.py, please add them there!")
    raise

print("My MAC addr:", [hex(i) for i in wifi.radio.mac_address])

print("Available WiFi networks:")
for network in wifi.radio.start_scanning_networks():
    print("\t%s\t\tRSSI: %d\tChannel: %d" % (str(network.ssid, "utf-8"),
            network.rssi, network.channel))
wifi.radio.stop_scanning_networks()
print("Connecting to %s"%secrets["ssid"])

try:
    print("Connecting to %s..." % secrets["ssid"])
    print("MAC: ", [hex(i) for i in wifi.radio.mac_address])
    wifi.radio.connect(secrets["ssid"], secrets["password"])
except:
    print("Error connecting to WiFi")
    raise

print("Connected to %s!"%secrets["ssid"])
print("My IP address is", wifi.radio.ipv4_address)
ipv4 = ipaddress.ip_address("8.8.4.4")
print("Ping google.com: %f ms" % (wifi.radio.ping(ipv4)*1000))

## Get random username and password

socket = socketpool.SocketPool(wifi.radio)
https = requests.Session(socket, ssl.create_default_context())
Creds_URL = ["https://raw.githubusercontent.com/danielmiessler/SecLists/master/Usernames/top-usernames-shortlist.txt", "https://raw.githubusercontent.com/danielmiessler/SecLists/master/Passwords/darkweb2017-top100.txt"]
def returnCreds(URLs):
    print("Fetching text from %s" % URLs)
    response = https.get(URLs)
    return response.text
    response.close()

usernamePool = returnCreds(Creds_URL[0]).splitlines()
passwordPool = returnCreds(Creds_URL[1]).splitlines()
gamePass = passwordPool[random.randint(0, (len(passwordPool)-1))]
gameUser = usernamePool[random.randint(0, len(usernamePool))]
print(gamePass)
print(gameUser)

## Setting up Ampule and socketpools

pool = socketpool.SocketPool(wifi.radio)
socket = pool.socket()
socket.bind(['0.0.0.0', 80])
socket.listen(1)

print("Connected to %s, IPv4 Addr: " % secrets["ssid"], wifi.radio.ipv4_address)

while True:
    ampule.listen(socket)
